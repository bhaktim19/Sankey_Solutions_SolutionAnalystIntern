package com.finalPayment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalPaymentApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinalPaymentApplication.class, args);
		System.out.println("My FinalPaymentApplication Is Running");
	}

}
