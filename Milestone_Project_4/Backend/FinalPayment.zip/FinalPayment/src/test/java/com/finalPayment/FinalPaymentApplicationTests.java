package com.finalPayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
