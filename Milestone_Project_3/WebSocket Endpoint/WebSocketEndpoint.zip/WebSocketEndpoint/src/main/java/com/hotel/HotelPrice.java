package com.hotel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HotelPrice {
	
	public float price;

	public float getPrice() {
		// TODO Auto-generated method stub
		return price;
	}

}
