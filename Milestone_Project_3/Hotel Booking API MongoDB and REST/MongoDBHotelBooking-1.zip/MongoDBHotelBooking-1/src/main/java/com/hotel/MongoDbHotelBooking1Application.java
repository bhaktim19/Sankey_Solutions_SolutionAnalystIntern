package com.hotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbHotelBooking1Application {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbHotelBooking1Application.class, args);
		System.out.println("My MongoDbHotelBooking1Application running");
	}

}
