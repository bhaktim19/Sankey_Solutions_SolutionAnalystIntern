package com.hotel.error;

public class GlobalExceptionHandling extends Exception
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GlobalExceptionHandling(String s)
    {
    	super(s);
    }
}
